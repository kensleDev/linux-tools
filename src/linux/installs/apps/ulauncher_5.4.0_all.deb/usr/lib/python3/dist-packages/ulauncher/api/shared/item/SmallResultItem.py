from .ResultItem import ResultItem


class SmallResultItem(ResultItem):
    ICON_SIZE = 25
    UI_FILE = 'small_result_item'
